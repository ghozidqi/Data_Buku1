<?php

include "koneksi.php";
$sql ="SELECT * FROM buku";
$query =mysqli_query($con, $sql);


?>

<!DOCTYPE html>
<html>
<head>
	<title>Data Buku</title>
</head>
<body>
   <h1>Data Buku</h1>
   <hr>

   <a href="tambahbuku.php"><button>tambah data</button></a><br></br>
   <table border="" ="1">
   	<tr>
   		<th>Id</th>
   		<th>Judul</th>
   		<th>Harga</th>
         <th>Stok</th>
   		<th>aksi</th>
   	</tr>
 <?php
 while ($buku = mysqli_fetch_array($query)) {
 	echo "<tr>";
 	echo "<td>" . $buku[0] . "</td>";
 	echo "<td>" . $buku[1] . "</td>";
 	echo "<td>" . $buku[2] . "</td>";
   echo "<td>" . $buku[3] . "</td>";
 	echo "<td><a href='editbuku.php?id=$buku[0]'>Edit</a>

 	          <a href='deletebuku.php?id=$buku[0]'>Hapus</a></td>";
 	echo "</tr>";
 }
 ?>
   </table>
</body>
</html>