<!DOCTYPE html>
<html>
<head>
	<title>Tambah Buku</title>
</head>
<body>

	<h1>Tambah Buku</h1>
	<hr>

	<form action="simpanbuku.php" method="GET">
		<label>Judul</label><br></br>
		<input type="text" name="judul"required><br>

		<label>Harga</label><br></br>
		<input type="text" name="harga"required><br>

		<label>Stok</label><br></br>
		<input type="text" name="stok"required><br>


		<input type="submit" name="simpan" value="Simpan">
	</form>

</body>
</html>