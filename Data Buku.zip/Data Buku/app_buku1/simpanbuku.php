<?php
include "koneksi.php";

if (isset($_GET['simpan'])) {
	$judul = $_GET['judul'];
	$harga = $_GET['harga'];
	$stok = $_GET['stok'];
	$sql = "INSERT INTO buku (judul, harga, stok) VALUES ('$judul','$harga','$stok')";
	$query = mysqli_query($con,$sql);

	if($query) {
		header("Location: index.php?simpan=sukses");
	}

}else {
	header("Location: index.php?pesan=gagal");
}

  ?>