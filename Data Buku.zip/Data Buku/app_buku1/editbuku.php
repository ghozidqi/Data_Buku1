<?php
include "koneksi.php";
$id = $_GET['id'];
$sql = "SELECT * FROM buku WHERE id = '$id'";
$query = mysqli_query($con,$sql);

 while ($buku = mysqli_fetch_array($query)) {

 ?>



<!DOCTYPE html>
<html>
<head>
	<title>Edit Buku</title>
</head>
<body>

	<h1>Edit Buku</h1>
	<hr>

	<form action="updatebuku.php" method="GET">
		<input type="hidden" name="id" value="<?php echo $buku [0]?>">
		<label>Judul</label><br>
		<input type="text" name="judul"value="<?php echo $buku [1]; ?>"required><br></br>

		<label>Harga</label><br>
		<input type="text" name="harga"value="<?php echo $buku [2]; ?>"required><br></br>

		<label>Stok</label><br>
		<input type="text" name="stok"value="<?php echo $buku [3]; ?>"required><br></br>

		<input type="submit" name="update" value="Update">
	</form>

</body>
</html>
<?php
}
?>