<?php

include "koneksi.php";

if (isset($_GET['update'])) {
	$id = $_GET['id'];
    $judul = $_GET['judul'];
	$harga = $_GET['harga'];
	$stok = $_GET['stok'];

	$sql = "UPDATE buku SET judul = '$judul',harga = '$harga',stok = '$stok'WHERE id ='$id'";
	$query = mysqli_query($con,$sql);

	if($query) {
		header("Location: index.php?simpan=sukses");
	} else {
		echo "ada kesalahan";
	}

} else {
	header("Location: index.php?pesan=gagal");
}

?>