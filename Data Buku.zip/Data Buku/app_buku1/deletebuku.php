<?php

include 'koneksi.php';
$id =$_GET['id'];

$sql=  "DELETE FROM buku WHERE id ='$id'";
$query = mysql_query($con,$sql);

if($query) {
	header("Location: index.php?hapus=sukses");
} else {
	header("Location: index.php?pesan=gagal");
}
?>